import { chromium } from "playwright-core";
import { writeFile } from "node:fs/promises";
const browser = await chromium.launch({
  executablePath: "/usr/bin/chromium",
  args: ["--no-sandbox", "--disable-dev-shm-usage"],
});
try {
  const page = await browser.newPage({
    viewport: { width: 1440, height: 1100 },
  });
  const errors = [];
  page.on("pageerror", (e) => errors.push(e.message));
  await page.goto("http://localhost:3000/SumoOResto", {
    waitUntil: "networkidle",
    timeout: 60000,
  });
  await page.waitForFunction(
    () => document.body.innerText.includes("SumoOResto"),
    { timeout: 30000 },
  );
  await page.keyboard.press("Space");
  for (const [delay, name] of [
    [2000, "gancho"],
    [5000, "calculo"],
    [6000, "problema"],
    [6000, "elegir"],
    [6000, "verificar"],
    [9000, "cta"],
  ]) {
    await page.waitForTimeout(delay);
    await page.screenshot({
      path: `review/studio-${name}.png`,
      fullPage: true,
    });
  }
  await page.keyboard.press("Space");
  await page.screenshot({ path: "review/studio.png", fullPage: true });
  const body = await page.locator("body").innerText();
  if (body.includes("Error loading composition") || errors.length)
    throw new Error(JSON.stringify(errors));
  const report = {
    composition: "SumoOResto",
    studioLoaded: true,
    playbackReviewedSeconds: 34,
    pageErrors: errors,
    checkedAt: new Date().toISOString(),
    scope:
      "Studio opened and playback exercised in Chromium; see screenshots for visual validation. No voiceover or video export.",
  };
  await writeFile(
    "review/studio-check.json",
    JSON.stringify(report, null, 2) + "\n",
  );
  console.log(JSON.stringify(report));
} finally {
  await browser.close();
}
