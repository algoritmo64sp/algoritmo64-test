import { Composition } from "remotion";
import { Reel } from "./Reel";
export const RemotionRoot = () => (
  <Composition
    id="SumoOResto"
    component={Reel}
    width={1080}
    height={1920}
    fps={30}
    durationInFrames={1140}
  />
);
