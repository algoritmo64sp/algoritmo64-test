import React from "react";
import {
  AbsoluteFill,
  Sequence,
  interpolate,
  useCurrentFrame,
  useVideoConfig,
  staticFile,
} from "remotion";

const blue = "#005B60";
const ink = "#080F35";
const sans = "ReelSans, sans-serif";
const serif = "Editorial, serif";
const clamp = { extrapolateLeft: "clamp", extrapolateRight: "clamp" } as const;
const Accent: React.FC<React.PropsWithChildren> = ({ children }) => (
  <em
    style={{
      color: blue,
      textDecoration: "underline",
      textDecorationThickness: 3,
      textUnderlineOffset: 10,
    }}
  >
    {children}
  </em>
);
const Pill: React.FC<React.PropsWithChildren> = ({ children }) => (
  <div
    style={{
      fontFamily: sans,
      fontSize: 28,
      fontWeight: 700,
      letterSpacing: 2,
      border: `2px solid ${ink}`,
      borderRadius: 40,
      padding: "15px 26px",
      alignSelf: "flex-start",
      background: "#FFFCF3",
      marginBottom: 44,
    }}
  >
    {children}
  </div>
);
const Title: React.FC<React.PropsWithChildren<{ size?: number }>> = ({
  children,
  size = 100,
}) => (
  <div
    style={{
      fontFamily: serif,
      fontSize: size,
      lineHeight: 1.04,
      letterSpacing: -2,
    }}
  >
    {children}
  </div>
);
const Caption: React.FC<React.PropsWithChildren> = ({ children }) => (
  <div
    style={{
      position: "absolute",
      top: 1160,
      left: 0,
      right: 0,
      display: "flex",
      justifyContent: "center",
    }}
  >
    <div
      style={{
        fontFamily: sans,
        fontSize: 38,
        lineHeight: 1.35,
        textAlign: "center",
        border: `2px solid ${ink}`,
        boxShadow: "0 5px 0 #080F35",
        padding: "17px 24px",
        borderRadius: 14,
        background: "#FFFCF3",
      }}
    >
      {children}
    </div>
  </div>
);
const Shell: React.FC<
  React.PropsWithChildren<{ dark?: boolean; immediate?: boolean }>
> = ({ children, dark = false, immediate = false }) => {
  const f = useCurrentFrame();
  return (
    <AbsoluteFill
      style={{
        color: dark ? "#FFFCF3" : ink,
        background: dark ? blue : "#FFFCF3",
        overflow: "hidden",
      }}
    >
      {!dark && (
        <>
          <div
            style={{
              position: "absolute",
              left: -180,
              top: 150,
              width: 700,
              height: 700,
              borderRadius: "50%",
              background: "#73D3F3",
              filter: "blur(120px)",
              opacity: 0.6,
            }}
          />
          <div
            style={{
              position: "absolute",
              right: -200,
              top: 660,
              width: 800,
              height: 700,
              borderRadius: "50%",
              background: "#BDEDE0",
              filter: "blur(140px)",
              opacity: 0.65,
            }}
          />
          <div
            style={{
              position: "absolute",
              left: 200,
              top: 80,
              width: 700,
              height: 500,
              borderRadius: "50%",
              background: "#FFE6A0",
              filter: "blur(150px)",
              opacity: 0.6,
            }}
          />
        </>
      )}
      <div
        style={{
          position: "absolute",
          left: 96,
          top: 160,
          fontFamily: sans,
          fontSize: 25,
          letterSpacing: 4,
        }}
      >
        ALGORITMO64{" "}
        <span style={{ opacity: 0.55 }}> / APRENDER CON SENTIDO</span>
      </div>
      <div
        style={{
          position: "absolute",
          left: 96,
          right: 144,
          top: 355,
          bottom: 480,
          display: "flex",
          flexDirection: "column",
          justifyContent: "center",
          opacity: immediate ? 1 : interpolate(f, [0, 10], [0, 1], clamp),
          translate: interpolate(
            f,
            [0, 14],
            [immediate ? "0px 0px" : "0px 24px", "0px 0px"],
            clamp,
          ),
        }}
      >
        {children}
      </div>
    </AbsoluteFill>
  );
};

const Pencil: React.FC<{ color?: string }> = ({ color = blue }) => (
  <svg width="46" height="145" viewBox="0 0 40 140" aria-label="lápiz">
    <path d="M8 24h24v88H8z" fill={color} />
    <path d="M8 24h8v88H8z" fill="#fff" opacity=".25" />
    <path d="M8 112l12 25 12-25" fill="#dcc29a" />
    <path d="M15 128l5 9 5-9" fill={ink} />
    <rect x="8" y="9" width="24" height="15" rx="5" fill="#e6a5a3" />
    <path d="M8 23h24v8H8z" fill="#c5c8cf" />
  </svg>
);
const Group: React.FC<{ count: number; color?: string }> = ({
  count,
  color,
}) => (
  <div
    style={{
      display: "grid",
      gridTemplateColumns: `repeat(${count === 5 ? 5 : 6},46px)`,
      gap: "14px 6px",
      justifyContent: "center",
    }}
  >
    {Array.from({ length: count }, (_, i) => (
      <Pencil key={i} color={color} />
    ))}
  </div>
);

const Hook = () => {
  const f = useCurrentFrame();
  return (
    <Shell immediate>
      <Pill>MATEMÁTICAS EN PRIMARIA</Pill>
      <Title size={112}>
        Sabe sumar.
        <br />
        Pero pregunta…
      </Title>
      <div
        style={{
          fontFamily: serif,
          fontSize: 148,
          lineHeight: 1.05,
          marginTop: 75,
          color: blue,
          opacity: interpolate(f, [0, 20], [0.85, 1], clamp),
        }}
      >
        ¿Sumo
        <br />o resto?
      </div>
      <Caption>¿Te pasa cuando leen un problema?</Caption>
    </Shell>
  );
};
const Calculation = () => {
  const f = useCurrentFrame();
  return (
    <Shell>
      <Pill>EL CÁLCULO</Pill>
      <Title>
        Esta cuenta
        <br />
        puede resultarle
        <br />
        <Accent>fácil.</Accent>
      </Title>
      <div
        style={{
          border: `3px solid ${ink}`,
          background: "#FFFCF3",
          borderRadius: 28,
          padding: "60px 25px",
          fontFamily: sans,
          fontSize: 104,
          letterSpacing: -5,
          marginTop: 65,
          textAlign: "center",
        }}
      >
        12 + 5{" "}
        <span
          style={{
            color: blue,
            opacity: interpolate(f, [18, 32], [0, 1], clamp),
          }}
        >
          = 17
        </span>
      </div>
      <Caption>Ahora cambiemos la pregunta.</Caption>
    </Shell>
  );
};
const Story = () => {
  const f = useCurrentFrame();
  return (
    <Shell>
      <Pill>EL PROBLEMA</Pill>
      <Title size={88}>
        Ana tiene
        <br />
        <Accent>12 lápices.</Accent>
        <br />
        Recibe 5 más.
      </Title>
      <div
        style={{
          display: "flex",
          alignItems: "center",
          justifyContent: "space-between",
          marginTop: 50,
          padding: 30,
          border: `2px solid ${ink}`,
          borderRadius: 24,
          background: "#ffffffa0",
        }}
      >
        <div>
          <Group count={12} />
          <div
            style={{
              textAlign: "center",
              fontFamily: sans,
              fontSize: 44,
              marginTop: 12,
            }}
          >
            TENÍA 12
          </div>
        </div>
        <div
          style={{
            opacity: interpolate(f, [28, 43], [0, 1], clamp),
            translate: interpolate(f, [28, 50], ["80px 0px", "0px 0px"], clamp),
          }}
        >
          <Group count={5} color="#FFC62F" />
          <div
            style={{
              textAlign: "center",
              fontFamily: sans,
              fontSize: 40,
              marginTop: 12,
            }}
          >
            RECIBE 5
          </div>
        </div>
      </div>
      <Caption>¿Cuántos lápices tiene ahora?</Caption>
    </Shell>
  );
};
const Choose = () => {
  const f = useCurrentFrame();
  return (
    <Shell>
      <Pill>COMPRENDER → ELEGIR</Pill>
      <Title size={98}>
        Recibe lápices.
        <br />
        Su cantidad
        <br />
        <Accent>aumenta.</Accent>
      </Title>
      <div
        style={{ display: "flex", gap: 22, marginTop: 70, fontFamily: sans }}
      >
        <div
          style={{
            border: `3px solid ${blue}`,
            background: "#D9F3ED",
            borderRadius: 24,
            padding: "32px 24px",
            fontSize: 65,
            color: blue,
            flex: 1,
            textAlign: "center",
          }}
        >
          12 + 5
        </div>
        <div
          style={{
            border: "2px solid #b5b7bc",
            borderRadius: 24,
            padding: "32px 24px",
            fontSize: 65,
            flex: 1,
            textAlign: "center",
            opacity: interpolate(f, [20, 40], [1, 0.28], clamp),
          }}
        >
          12 − 5
        </div>
      </div>
      <Caption>Entender lo que ocurre ayuda a elegir.</Caption>
    </Shell>
  );
};
const Verify = () => {
  const f = useCurrentFrame();
  return (
    <Shell>
      <Pill>VERIFICAR</Pill>
      <Title size={94}>
        Si recibió más…
        <br />
        ¿puede terminar
        <br />
        con <Accent>menos?</Accent>
      </Title>
      <div
        style={{
          fontFamily: sans,
          fontSize: 95,
          marginTop: 65,
          display: "flex",
          alignItems: "center",
          gap: 40,
        }}
      >
        <span
          style={{
            textDecoration: "line-through",
            textDecorationColor: "#bb6254",
            opacity: interpolate(f, [8, 22], [0, 1], clamp),
          }}
        >
          7
        </span>
        <span
          style={{
            color: blue,
            opacity: interpolate(f, [35, 50], [0, 1], clamp),
          }}
        >
          17 lápices
        </span>
      </div>
      <Caption>Un error aislado no define su aprendizaje.</Caption>
    </Shell>
  );
};
const Closing = () => {
  const f = useCurrentFrame();
  return (
    <AbsoluteFill
      style={{
        background:
          "linear-gradient(155deg, #73D3F3 0%, #E9F9FA 36%, #FFFCF3 68%, #D9F3ED 100%)",
        color: ink,
        overflow: "hidden",
      }}
    >
      <svg
        width="1080"
        height="1920"
        viewBox="0 0 1080 1920"
        style={{ position: "absolute", inset: 0 }}
        aria-hidden="true"
      >
        <path
          d="M1190 180 Q590 110 855 445 Q1120 780 905 1030 Q650 1320 1110 1690"
          fill="none"
          stroke="#ffffff"
          strokeWidth="100"
          opacity=".6"
        />
        <path
          d="M1190 180 Q590 110 855 445 Q1120 780 905 1030 Q650 1320 1110 1690"
          fill="none"
          stroke="#FFC62F"
          strokeWidth="8"
          strokeDasharray="14 20"
          opacity=".8"
        />
        <circle cx="925" cy="300" r="58" fill="#FFC62F" />
      </svg>
      <div
        style={{
          position: "absolute",
          left: 96,
          top: 160,
          fontFamily: sans,
          fontSize: 30,
          fontWeight: 700,
          letterSpacing: 1,
        }}
      >
        ALGORITMO<span style={{ color: "#008CFF" }}>64</span>
      </div>
      <div
        style={{
          position: "absolute",
          left: 96,
          right: 144,
          top: 355,
          opacity: interpolate(f, [0, 12], [0, 1], clamp),
          translate: interpolate(f, [0, 18], ["0px 22px", "0px 0px"], clamp),
        }}
      >
        <div
          style={{
            display: "inline-block",
            fontFamily: sans,
            fontSize: 27,
            letterSpacing: 3,
            fontWeight: 700,
            background: "#FFC62F",
            padding: "16px 25px",
            borderRadius: 40,
          }}
        >
          CURSO DE VERANO 2027
        </div>
        <div
          style={{
            fontFamily: sans,
            fontSize: 112,
            fontWeight: 900,
            lineHeight: 1.08,
            letterSpacing: -5,
            marginTop: 45,
          }}
        >
          La Ruta
          <br />
          del <span style={{ color: blue }}>Verano.</span>
        </div>
        <div
          style={{
            width: 120,
            height: 9,
            background: "#FFC62F",
            borderRadius: 9,
            marginTop: 35,
          }}
        />
        <div
          style={{
            fontFamily: sans,
            fontSize: 43,
            lineHeight: 1.35,
            marginTop: 36,
          }}
        >
          Conoce el programa para
          <br />
          estas vacaciones.
        </div>
        <div
          style={{
            marginTop: 62,
            padding: "42px 38px",
            background: "#FFFCF3",
            border: "2px solid #B6DFD9",
            borderRadius: 36,
            boxShadow: "0 20px 60px #005B6015",
          }}
        >
          <div
            style={{
              fontFamily: sans,
              fontSize: 25,
              letterSpacing: 3,
              color: blue,
              fontWeight: 700,
            }}
          >
            TU SIGUIENTE PASO
          </div>
          <div
            style={{
              fontFamily: sans,
              fontSize: 43,
              lineHeight: 1.3,
              fontWeight: 700,
              marginTop: 25,
            }}
          >
            Ve a nuestro perfil.
          </div>
          <div
            style={{
              display: "flex",
              gap: 18,
              alignItems: "center",
              marginTop: 30,
            }}
          >
            <div
              style={{
                width: 56,
                height: 56,
                borderRadius: 28,
                background: "#D9F3ED",
                display: "flex",
                alignItems: "center",
                justifyContent: "center",
                flexShrink: 0,
              }}
            >
              <svg
                width="30"
                height="30"
                viewBox="0 0 24 24"
                fill="none"
                stroke="#005B60"
                strokeWidth="2"
              >
                <path d="M10 13a5 5 0 007 0l3-3a5 5 0 00-7-7l-2 2M14 11a5 5 0 00-7 0l-3 3a5 5 0 007 7l2-2" />
              </svg>
            </div>
            <div style={{ fontFamily: sans, fontSize: 37, lineHeight: 1.35 }}>
              Haz clic en el
              <br />
              <strong>enlace de la bio.</strong>
            </div>
          </div>
          <div
            style={{
              marginTop: 35,
              borderRadius: 24,
              background: "linear-gradient(110deg,#009B72,#00785B)",
              color: "#FFFFFF",
              padding: "28px 28px",
              display: "flex",
              alignItems: "center",
              justifyContent: "space-between",
              gap: 20,
              fontFamily: sans,
              fontSize: 34,
              fontWeight: 700,
              boxShadow: "inset 0 0 0 2px #ffffff30",
            }}
          >
            CONOCE LA RUTA{" "}
            <span style={{ fontSize: 46, lineHeight: 1 }}>↗</span>
          </div>
        </div>
      </div>
    </AbsoluteFill>
  );
};

export const Reel = () => {
  const { fps } = useVideoConfig();
  return (
    <AbsoluteFill>
      <style>{`@font-face{font-family:Editorial;src:url('${staticFile("fonts/editorial.otf")}')}@font-face{font-family:Editorial;src:url('${staticFile("fonts/editorial-italic.otf")}');font-style:italic}@font-face{font-family:ReelSans;src:url('${staticFile("fonts/sans.ttf")}')}*{box-sizing:border-box}`}</style>
      <Sequence name="01 · Gancho" durationInFrames={5 * fps}>
        <Hook />
      </Sequence>
      <Sequence name="02 · Cálculo" from={5 * fps} durationInFrames={4 * fps}>
        <Calculation />
      </Sequence>
      <Sequence
        name="03 · Problema visual"
        from={9 * fps}
        durationInFrames={7 * fps}
      >
        <Story />
      </Sequence>
      <Sequence
        name="04 · Elegir la operación"
        from={16 * fps}
        durationInFrames={6 * fps}
      >
        <Choose />
      </Sequence>
      <Sequence
        name="05 · Verificar"
        from={22 * fps}
        durationInFrames={6 * fps}
      >
        <Verify />
      </Sequence>
      <Sequence
        name="06 · La Ruta del Verano"
        from={28 * fps}
        durationInFrames={10 * fps}
      >
        <Closing />
      </Sequence>
    </AbsoluteFill>
  );
};
