# ALGORITMO64 · ¿Sumo o resto?

Primera composición visual del Reel de La Ruta del Verano 2027. Proyecto independiente; no modifica `algoritmo64-test`.

- Remotion 4.0.541, React 19, TypeScript.
- 1080×1920 · 30 fps · 38 s · composición `SumoOResto`.
- Escenas y animación: `src/Reel.tsx`.
- Guion, fuente, decisiones, CTA y pendientes: [docs/PREPRODUCCION.md](docs/PREPRODUCCION.md).
- Fotogramas de revisión: `review/`.

## Uso

```bash
cd /workspace/reel-sumo-resto
npm ci --no-audit --no-fund --cache /workspace/.npm-cache
npm run dev -- --port 3000
```

Studio es una herramienta local de trabajo. No se publica automáticamente ni se genera un enlace público.

```bash
npm run lint
npm run build
node scripts/revisar-studio.mjs
```

La revisión de navegador usa `/usr/bin/chromium`, disponible en este entorno, y requiere Studio iniciado. El proyecto se compiló y se revisaron fotogramas con Chromium. No hay locución, música ni subtítulos finales. No se ha exportado un MP4 ni verificado el enlace real de la bio.

Para generar un fotograma sin exportar el video:

```bash
npx remotion still src/index.ts SumoOResto review/gancho.png --frame=65 --browser-executable=/usr/bin/chromium
```

En una futura tarea, usar este directorio existente; no crear un worktree salvo petición explícita. Reiniciar Studio porque los procesos no se conservan necesariamente entre sesiones.
