# Prueba de voz en CapCut

Estado: textos preparados. No se ha operado CapCut ni generado audio desde esta sesión; no hay conexión disponible.

1. Crear un proyecto vertical 9:16. Añadir un fondo temporal si CapCut lo requiere para la prueba.
2. Añadir como texto el contenido de `01-prueba-de-voz.txt`. Buscar Texto a voz / Text to speech (nombre y ubicación dependen de versión/dispositivo).
3. Escuchar dos voces en español latino con el mismo texto. Priorizar dicción natural, interrogación expresiva y tono cercano a padres. La opción femenina cálida es una dirección creativa; no una voz viral verificada.
4. Mantener velocidad normal al principio. Evitar efectos de personaje, exageración y acelerar para forzar los 38 segundos. Anotar nombre exacto, variante e idioma de la voz elegida.
5. Generar `02-narracion-completa.txt` con la voz elegida, idealmente en una sola toma para conservar entonación. Si la herramienta exige bloques, usar los seis párrafos y conservar la misma configuración.
6. Escuchar que «doce más cinco», «diecisiete» (si se añade después) y «La Ruta del Verano» se pronuncien correctamente, sin leer signos o comillas. No cambiar el CTA aprobado.
7. Entregar la narración sin música. Exportar audio si la versión lo permite; si no, exportar un video con ese audio. No hace falta exportar las capas de texto de la prueba.

La duración se medirá con el audio real y se ajustará la composición Remotion. Los subtítulos se producirán después con la toma definitiva. No se ha creado un proyecto nativo de CapCut. El texto de prueba incluye contexto extra para comparar entonación; la narración completa conserva el guion de producción vigente.
