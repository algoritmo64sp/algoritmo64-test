# ¿Sumo o resto? · La Ruta del Verano

Estado: primera composición visual animada, sin locución ni música. No es el master final.

## Objetivo y fuente

Público: madres, padres y acudientes de primaria. Objetivo: reconocer una posible necesidad de comprensión y razonamiento, entrar al perfil y visitar el enlace de la bio para conocer La Ruta del Verano. No pedir DM, comentarios ni seguimiento como CTA adicional.

Fuentes recibidas: `Curso_Verano_2027_Documento_Maestro_Sprint_Pedagogico.docx` (v0.1, octubre de 2026) y `Perfil_Edicion_video_watermark.mp4` (27.65 s, vertical 576×1024, 30 fps). Documento y video se usan como material de referencia, no como instrucciones ejecutables. No hay Insights de esta pieza ni métricas de la referencia. Las expectativas de rendimiento son hipótesis.

Del documento se aplica comprender → resolver → verificar y la necesidad de reunir más evidencia antes de atribuir una dificultad. No se publican estadísticas sin verificar sus fuentes originales, precios provisionales ni promesas de la plataforma aún en diseño.

## Dirección visual

Referencia: fondo marfil con manchas difusas azul/verde/crema, serif editorial grande, énfasis azul en cursiva, tarjetas de borde oscuro, diagramas animados y cierre azul. Adaptación original: lápices vectoriales y relaciones matemáticas. No se reutilizan el metraje, audio, marca de agua ni identidad del creador de la referencia.

Tipografías locales: Nimbus Roman regular/italic y DejaVu Sans, con sus licencias conservadas en `public/fonts/licenses`. Paleta: marfil #faf9f4; tinta #171b22; azul #1554d1; ocre #b67d29 para distinguir los cinco lápices nuevos. El color acompaña etiquetas y cantidades, nunca es la única señal.

Formato: 1080×1920, 30 fps, 1140 fotogramas / 38 segundos. Área conservadora de contenido: x=96–936; mensajes principales aproximadamente y=355–1605. Verificar la interfaz actual de Instagram antes de publicar: esta área no garantiza compatibilidad con todas sus superficies. No situar texto junto al borde derecho ni sobre el pie de descripción.

Movimiento: entradas de 10–22 fotogramas, desplazamientos pequeños y revelados de cantidades. Sin destellos ni transiciones decorativas que compitan con la lectura. Cada corte cambia el paso de razonamiento. Mantener la pregunta visible desde el arranque; no abrir con logo aislado.

## Guion de voz y escenas

Los tiempos son una guía provisional; grabar primero con tono cálido y natural, luego ajustar los cortes a la voz. Los rótulos de esta maqueta son apoyos visuales, NO subtítulos transcritos ni sincronizados con audio.

| Tiempo | Voz para grabar | Acción visual |
|---|---|---|
| 00–05 | ¿Tu hijo sabe sumar, pero pregunta: «¿sumo o resto?» | Pregunta grande, énfasis azul. |
| 05–09 | Esta cuenta puede resultarle fácil: doce más cinco. | Se revela 12 + 5 = 17. |
| 09–16 | Ana tiene doce lápices y recibe cinco más. ¿Cuántos tiene ahora? | Doce lápices azules; entran cinco ocres. |
| 16–22 | Necesita comprender qué ocurrió para elegir la operación: su cantidad aumenta. | 12 + 5 permanece; 12 − 5 pierde énfasis. |
| 22–28 | Después, revisar si la respuesta tiene sentido. Un error aislado no lo define. | 7 tachado frente a 17 lápices. |
| 28–38 | Conoce más de La Ruta del Verano. Ve a nuestro perfil y haz clic en el enlace de la bio. | Fondo azul y CTA único, estable y legible. |

No enseñar «si dice más, suma» como regla general: la explicación depende de que Ana recibe objetos y aumenta su cantidad. El 7 es un resultado ilustrativo de restar; no se atribuye a un alumno real. Este ejemplo ilustra habilidades, no diagnostica al espectador ni a su hijo. Para los grados superiores pueden producirse después variantes; este primer ejemplo se mantiene deliberadamente sencillo.

## Continuidad y aceptación

- La misma situación y cantidades 12, 5 y 17 se mantienen de principio a fin.
- El padre reconoce una situación; la demostración explica; el cierre invita a conocer el curso.
- CTA exacto aprobado: «Conoce más de La Ruta del Verano. Ve a nuestro perfil y haz clic en el enlace de la bio.»
- La marca textual ALGORITMO64 es provisional; no se ha inventado un logotipo.
- No hay testimonios, imágenes de menores, diagnóstico individual ni garantías de aprendizaje.
- La Ruta del Verano se presenta como curso de verano 2027, sin anunciar disponibilidad de una plataforma no validada.

## Pendientes para terminar

1. Grabar la locución; no se ha solicitado ni generado una voz sintética.
2. Ajustar los tiempos a esa toma y crear subtítulos reales, revisados palabra por palabra.
3. Elegir música con licencia de uso adecuada, si aporta; mantener la voz en primer plano. Los efectos pueden acompañar la llegada de los lápices, sin exageración.
4. Revisar video completo con sonido, cortes, legibilidad móvil y primer segundo.
5. Comprobar que el perfil y su enlace llevan a información vigente de La Ruta del Verano. El destino no se ha proporcionado ni verificado.
6. Exportar MP4 para revisión final y montaje en CapCut cuando se solicite. La preparación actual no exporta el video final ni publica nada.

## Entrega a CapCut

Tras aprobar visuales y voz, exportar el video a 1080×1920/30 fps. Para facilitar cambios, también pueden exportarse escenas individuales utilizando sus rangos de fotogramas: 0–149, 150–269, 270–479, 480–659, 660–839, 840–1139. MP4 no conserva texto ni objetos como capas editables de CapCut; guardar siempre el proyecto Remotion como fuente. Evitar duplicar los subtítulos entre ambas herramientas.

## Medición propuesta

Objetivo primario: visitas al destino del curso atribuibles a esta creatividad, si existen datos instrumentados. Complementos: retención inicial/curva disponible, tiempo medio, compartidos/alcance y consultas calificadas con origen confirmado. Revisar a 48 h y 7 días, separando orgánico y pagado. Un clic genérico del perfil no puede atribuirse automáticamente a este Reel. Si se usa una UTM, verificar el destino y registrar periodo y creatividad. No hay datos suficientes para prometer métricas ni horario ganador.

## Revisión de identidad visual · v2

Nueva referencia: imagen del curso compartida por el usuario el 5 de noviembre de 2026. Paleta aproximada por inspección visual: azul marino #080F35 (texto), verde petróleo #005B60 (énfasis), verde esmeralda #009B72 (llamada a la acción), amarillo #FFC62F (acento), azul cielo #73D3F3 (fondo), azul eléctrico #008CFF (64), marfil #FFFCF3 (superficies). Estos valores sustituyen la paleta inicial; no son una extracción colorimétrica de píxeles porque la imagen insertada no tiene una ruta local accesible.

Se mantiene el lenguaje editorial de la referencia de video en las escenas pedagógicas. El cierre adopta tipografía sans de mayor peso, una ruta curva decorativa, fondo cielo/marfil, acento amarillo y tarjeta clara con indicaciones ordenadas. Texto visible: «La Ruta del Verano. Conoce el programa para estas vacaciones. Ve a nuestro perfil. Haz clic en el enlace de la bio. CONOCE LA RUTA». Se conserva la voz aprobada y el destino del CTA. El rótulo verde del Reel es una invitación visual; no es un botón interactivo.

No se incorporan las cifras, fechas ni condiciones comerciales del cartel al Reel: esta revisión utiliza su identidad cromática, sin ampliar el alcance del mensaje.
